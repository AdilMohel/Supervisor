package com.example.supervisior_anbar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
