const regular = "Inter-Regular";
const semibold = "Inter-SemiBold";
const bold = "Inter-Bold";
const mediam = "Inter-Medium";
// TODO Implement this library.