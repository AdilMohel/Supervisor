// import 'package:flutter/material.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:get/get_core/src/get_main.dart';
// import 'package:get/get_navigation/get_navigation.dart';
// import 'package:supervisior_anbar/consts/colors.dart';
// import 'package:supervisior_anbar/consts/consts.dart';
//
// import '../../../widget_common/commen_header.dart';
//
// class TechnicianDetail extends StatelessWidget {
//   final String technicianId; // Pass the technician ID to fetch data from Firestore
//
//   const TechnicianDetail({Key? key, required this.technicianId})
//       : super(key: key);
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: whiteColor,
//       body: SafeArea(
//         child: SingleChildScrollView(
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Container(
//                 height: 100,
//                 width: double.infinity,
//                 color: primaryColor,
//                 child: Padding(
//                   padding: const EdgeInsets.only(left: 20, right: 20, top: 40),
//                   child: Row(
//                     children: [
//                       IconButton(
//                         onPressed: () {
//                           Get.back();
//                         },
//                         icon: Icon(Icons.arrow_back_ios, color: whiteColor),
//                       ),
//                       Image.asset(imgANBARtl, width: 165, height: 45),
//                     ],
//                   ),
//                 ),
//               ),
//               SizedBox(height: 10),
//
//               // Technician Details Section
//               Padding(
//                 padding: const EdgeInsets.symmetric(horizontal: 20),
//                 child: StreamBuilder<DocumentSnapshot>(
//                   stream: FirebaseFirestore.instance.collection('technicians')
//                       .doc(technicianId)
//                       .snapshots(),
//                   builder: (context, snapshot) {
//                     if (snapshot.connectionState == ConnectionState.waiting) {
//                       return Center(child: CircularProgressIndicator());
//                     }
//
//                     if (snapshot.hasError) {
//                       return Center(child: Text('Error: ${snapshot.error}'));
//                     }
//
//                     if (!snapshot.hasData || !snapshot.data!.exists) {
//                       return Center(child: Text('Technician not found.'));
//                     }
//
//                     var technician = snapshot.data!.data() as Map<
//                         String,
//                         dynamic>;
//
//                     return Container(
//                       padding: EdgeInsets.symmetric(
//                           horizontal: 20, vertical: 20),
//                       decoration: BoxDecoration(
//                         color: whiteColor,
//                         borderRadius: BorderRadius.all(Radius.circular(10)),
//                         boxShadow: [
//                           BoxShadow(
//                             color: blackColor.withOpacity(0.3),
//                             spreadRadius: 0,
//                             blurRadius: 5,
//                             offset: Offset(0, 4),
//                           ),
//                         ],
//                       ),
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           Row(
//                             children: [
//                               Text(
//                                 techniciandetail,
//                                 style: TextStyle(
//                                   color: blackColor,
//                                   fontSize: 20,
//                                   fontFamily: 'Bold',
//                                 ),
//                               ),
//                               Spacer(),
//                               CircleAvatar(
//                                 radius: 20,
//                                 backgroundColor: lightblue,
//                                 backgroundImage: technician['profile_image'] !=
//                                     null
//                                     ? NetworkImage(technician['profile_image'])
//                                     : null,
//                                 child: technician['profile_image'] == null
//                                     ? Icon(
//                                     Icons.person, size: 15, color: whiteColor)
//                                     : null,
//                               ),
//                             ],
//                           ),
//                           SizedBox(height: 10),
//                           Row(
//                             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                             children: [
//                               Text(
//                                 name,
//                                 style: TextStyle(
//                                   color: blackColor,
//                                   fontSize: 14,
//                                   fontFamily: 'Regular',
//                                 ),
//                               ),
//                               Text(
//                                 '${technician['first_name']} ${technician['last_name']}',
//                                 style: TextStyle(
//                                   color:  blackColor,
//                                   fontSize: 14,
//                                   fontFamily: 'Regular',
//                                 ),
//                               ),
//                             ],
//                           ),
//                           SizedBox(height: 10),
//                           Row(
//                             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                             children: [
//                               Text(
//                                 email,
//                                 style: TextStyle(
//                                   color: blackColor,
//                                   fontSize: 14,
//                                   fontFamily: 'Regular',
//                                 ),
//                               ),
//                               Text(
//                                 technician['email'],
//                                 style: TextStyle(
//                                   color: blackColor,
//                                   fontSize: 14,
//                                   fontFamily: 'Regular',
//                                 ),
//                               ),
//                             ],
//                           ),
//                           SizedBox(height: 10),
//                           Row(
//                             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                             children: [
//                               Text(
//                                 speciality,
//                                 style: TextStyle(
//                                   color: blackColor,
//                                   fontSize: 14,
//                                   fontFamily: 'Regular',
//                                 ),
//                               ),
//                               Text(
//                                 technician['speciality'],
//                                 style: TextStyle(
//                                   color: blackColor,
//                                   fontSize: 14,
//                                   fontFamily: 'Regular',
//                                 ),
//                               ),
//                             ],
//                           ),
//                           SizedBox(height: 10),
//                           Row(
//                             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                             children: [
//                               Text(
//                                 phoneNumber,
//                                 style: TextStyle(
//                                   color: blackColor,
//                                   fontSize: 14,
//                                   fontFamily: 'Regular',
//                                 ),
//                               ),
//                               Text(
//                                 technician['phone'],
//                                 style: TextStyle(
//                                   color: blackColor,
//                                   fontSize: 14,
//                                   fontFamily: 'Regular',
//                                 ),
//                               ),
//                             ],
//                           ),
//                           SizedBox(height: 10),
//                           Row(
//                             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                             children: [
//                               Text(
//                                 gender,
//                                 style: TextStyle(
//                                   color: blackColor,
//                                   fontSize: 14,
//                                   fontFamily: 'Regular',
//                                 ),
//                               ),
//                               Text(
//                                 technician['gender'],
//                                 style: TextStyle(
//                                   color: blackColor,
//                                   fontSize: 14,
//                                   fontFamily: 'Regular',
//                                 ),
//                               ),
//                             ],
//                           ),
//                         ],
//                       ),
//                     );
//                   },
//                 ),
//               ),
//
//               SizedBox(height: 20),
//
//               // CNIC Images Section
//               Padding(
//                 padding: const EdgeInsets.symmetric(horizontal: 20),
//                 child: StreamBuilder<DocumentSnapshot>(
//                   stream: FirebaseFirestore.instance.collection('technicians')
//                       .doc(technicianId)
//                       .snapshots(),
//                   builder: (context, snapshot) {
//                     if (snapshot.connectionState == ConnectionState.waiting) {
//                       return Center(child: CircularProgressIndicator());
//                     }
//
//                     if (snapshot.hasError) {
//                       return Center(child: Text('Error: ${snapshot.error}'));
//                     }
//
//                     if (!snapshot.hasData || !snapshot.data!.exists) {
//                       return Center(child: Text('Technician not found.'));
//                     }
//
//                     var technician = snapshot.data!.data() as Map<
//                         String,
//                         dynamic>;
//
//                     return Container(
//                       height: 140,
//                       width: double.infinity,
//                       decoration: BoxDecoration(
//                         color: whiteColor,
//                         borderRadius: BorderRadius.all(Radius.circular(5)),
//                         boxShadow: [
//                           BoxShadow(
//                             color: Colors.black.withOpacity(0.3),
//                             spreadRadius: 0,
//                             blurRadius: 5,
//                             offset: Offset(0, 4),
//                           ),
//                         ],
//                       ),
//                       child: Column(
//                         mainAxisAlignment: MainAxisAlignment.center,
//                         children: [
//                           Padding(
//                             padding: const EdgeInsets.symmetric(horizontal: 20),
//                             child: Row(
//                               children: [
//                                 Text(
//                                   cnic,
//                                   style: TextStyle(
//                                     color: blackColor,
//                                     fontSize: 16,
//                                     fontFamily: 'Bold',
//                                   ),
//                                 ),
//                               ],
//                             ),
//                           ),
//                           SizedBox(height: 10),
//                           Padding(
//                             padding: const EdgeInsets.symmetric(horizontal: 50),
//                             child: Row(
//                               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                               children: [
//                                 Container(
//                                   height: 70,
//                                   width: 100,
//                                   decoration: BoxDecoration(
//                                     borderRadius: BorderRadius.all(
//                                         Radius.circular(5)),
//                                   ),
//                                   child: technician['cnic_front_image'] != null
//                                       ? Image.network(
//                                     technician['cnic_front_image'],
//                                     fit: BoxFit.cover,
//                                     errorBuilder: (context, error, stackTrace) {
//                                       return Center(
//                                           child: Text('Image not available'));
//                                     },
//                                   )
//                                       : Center(
//                                       child: Text('Image not available')),
//                                 ),
//                                 Container(
//                                   height: 70,
//                                   width: 100,
//                                   decoration: BoxDecoration(
//                                     borderRadius: BorderRadius.all(
//                                         Radius.circular(5)),
//                                   ),
//                                   child: technician['cnic_back_image'] != null
//                                       ? Image.network(
//                                     technician['cnic_back_image'],
//                                     fit: BoxFit.cover,
//                                     errorBuilder: (context, error, stackTrace) {
//                                       return Center(
//                                           child: Text('Image not available'));
//                                     },
//                                   )
//                                       : Center(
//                                       child: Text('Image not available')),
//                                 ),
//                               ],
//                             ),
//                           ),
//                         ],
//
//                       ),
//                     );
//                   },
//                 ),
//               ),
//               SizedBox(height: 20),
//
//
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';
import 'package:supervisior_anbar/consts/colors.dart';
import 'package:supervisior_anbar/consts/consts.dart';

class TechnicianDetail extends StatelessWidget {
  final String technicianId;

  const TechnicianDetail({Key? key, required this.technicianId})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: whiteColor,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                height: 100,
                width: double.infinity,
                color: primaryColor,
                child: Padding(
                  padding: const EdgeInsets.only(left: 20, right: 20, top: 40),
                  child: Row(
                    children: [
                      IconButton(
                        onPressed: () {
                          Get.back();
                        },
                        icon: Icon(Icons.arrow_back_ios, color: whiteColor),
                      ),
                      Image.asset(imgANBARtl, width: 165, height: 45),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 10),

              // Technician Details Section
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: StreamBuilder<DocumentSnapshot>(
                  stream: FirebaseFirestore.instance.collection('technicians').doc(technicianId).snapshots(),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return Center(child: CircularProgressIndicator());
                    }

                    if (snapshot.hasError) {
                      return Center(child: Text('Error: ${snapshot.error}'));
                    }

                    if (!snapshot.hasData || !snapshot.data!.exists) {
                      return Center(child: Text('Technician not found.'));
                    }

                    var technician = snapshot.data!.data() as Map<String, dynamic>;

                    return Container(
                      padding: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                      decoration: BoxDecoration(
                        color: whiteColor,
                        borderRadius: BorderRadius.all(Radius.circular(10)),
                        boxShadow: [
                          BoxShadow(
                            color: blackColor.withOpacity(0.3),
                            spreadRadius: 0,
                            blurRadius: 5,
                            offset: Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Text(
                                techniciandetail,
                                style: TextStyle(
                                  color: blackColor,
                                  fontSize: 20,
                                  fontFamily: 'Bold',
                                ),
                              ),
                              Spacer(),
                              CircleAvatar(
                                radius: 20,
                                backgroundColor: lightblue,
                                backgroundImage: technician['profile_image'] != null
                                    ? NetworkImage(technician['profile_image'])
                                    : null,
                                child: technician['profile_image'] == null
                                    ? Icon(Icons.person, size: 15, color: whiteColor)
                                    : null,
                              ),
                            ],
                          ),
                          SizedBox(height: 10),
                          buildDetailRow('Name', '${technician['first_name']} ${technician['last_name']}'),
                          buildDetailRow('Email', technician['email']),
                          buildDetailRow('Speciality', technician['speciality']),
                          buildDetailRow('Phone Number', technician['phone']),
                          buildDetailRow('Gender', technician['gender']),
                          SizedBox(height: 20),
                          buildStatusSection(technician, technicianId),
                        ],
                      ),
                    );
                  },
                ),
              ),

              SizedBox(height: 20),

              // CNIC Images Section
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: StreamBuilder<DocumentSnapshot>(
                  stream: FirebaseFirestore.instance.collection('technicians').doc(technicianId).snapshots(),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return Center(child: CircularProgressIndicator());
                    }

                    if (snapshot.hasError) {
                      return Center(child: Text('Error: ${snapshot.error}'));
                    }

                    if (!snapshot.hasData || !snapshot.data!.exists) {
                      return Center(child: Text('Technician not found.'));
                    }

                    var technician = snapshot.data!.data() as Map<String, dynamic>;

                    return Container(
                      height: 140,
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: whiteColor,
                        borderRadius: BorderRadius.all(Radius.circular(5)),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.3),
                            spreadRadius: 0,
                            blurRadius: 5,
                            offset: Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 20),
                            child: Row(
                              children: [
                                Text(
                                  cnic,
                                  style: TextStyle(
                                    color: blackColor,
                                    fontSize: 16,
                                    fontFamily: 'Bold',
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 10),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 50),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                buildCnicImage(technician['cnic_front_image']),
                                buildCnicImage(technician['cnic_back_image']),
                              ],
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
              SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildDetailRow(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: TextStyle(
            color: blackColor,
            fontSize: 14,
            fontFamily: 'Regular',
          ),
        ),
        Spacer(),
        Text(
          value,
          style: TextStyle(
            color: blackColor,
            fontSize: 14,
            fontFamily: 'Regular',
          ),
        ),
      ],
    );
  }

  Widget buildCnicImage(String? url) {
    return Container(
      height: 70,
      width: 100,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.all(Radius.circular(5)),
      ),
      child: url != null
          ? Image.network(
        url,
        fit: BoxFit.cover,
        errorBuilder: (context, error, stackTrace) {
          return Center(child: Text('Image not available'));
        },
      )
          : Center(child: Text('Image not available')),
    );
  }

  Widget buildStatusSection(Map<String, dynamic> technician, String technicianId) {
    bool status = technician['status'] ?? true;
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          'Status',
          style: TextStyle(
            color: blackColor,
            fontSize: 14,
            fontFamily: 'Regular',
          ),
        ),
        Spacer(),
        GestureDetector(
          onTap: () {
            bool newStatus = !status;
            FirebaseFirestore.instance
                .collection('technicians')
                .doc(technicianId)
                .update({'status': newStatus});
          },
          child: Container(
            height: 30,
            width: 100,
            decoration: BoxDecoration(
              color: status ? primaryColor : redColor,
              borderRadius: BorderRadius.circular(5),
            ),
            child: Center(
              child: Text(
                status ? 'Active' : 'Banned',
                style: TextStyle(
                  color: whiteColor,
                  fontSize: 14,
                  fontFamily: 'Regular',
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
